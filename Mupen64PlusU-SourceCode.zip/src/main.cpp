#include <coreinit/core.h>
#include <coreinit/screen.h>
#include <vpad/input.h>
#include <whb/proc.h>
#include <whb/log.h>
#include <whb/log_udp.h>
#include <gx2/draw.h>
#include <vector>
#include <string>
#include <cstring>
#include <cstdlib>
#include <dirent.h>

struct GX2Texture { uint32_t dummy; }; 
struct WiiUTexture { GX2Texture gx2_tex; void* buffer; uint32_t width; uint32_t height; bool is_loaded; };

extern "C" {
    bool Texture_LoadRGBA(WiiUTexture* tex, const void* rgba_data, uint32_t w, uint32_t h);
    void Texture_Bind(WiiUTexture* tex, uint32_t sampler_unit);
    void Texture_Free(WiiUTexture* tex);
    bool SaveState_Create(const char* rom_name, int slot);
    bool SaveState_Load(const char* rom_name, int slot);
}

struct N64Controller { uint16_t buttons; int8_t stick_x; int8_t stick_y; };
struct RomEntry { std::string filename; std::string display_name; WiiUTexture cover; };

enum AspectRatio {
    ASPECT_16_9 = 0,
    ASPECT_4_3  = 1
};

uint8_t* g_n64_ram = nullptr;
uint32_t g_n64_ram_size = 8 * 1024 * 1024;

void mupen_init() { g_n64_ram = (uint8_t*)std::malloc(g_n64_ram_size); }
void mupen_load_rom(const char* path) {}
void mupen_run_frame(N64Controller* pad) {}
void mupen_shutdown() { if(g_n64_ram) std::free(g_n64_ram); }

void ApplyAspectRatio(AspectRatio ratio) {
    if (ratio == ASPECT_16_9) {
        GX2SetViewport(0.0f, 0.0f, 1280.0f, 720.0f, 0.0f, 1.0f);
        GX2SetScissor(0, 0, 1280, 720);
    } else if (ratio == ASPECT_4_3) {
        GX2SetViewport(160.0f, 0.0f, 960.0f, 720.0f, 0.0f, 1.0f);
        GX2SetScissor(160, 0, 960, 720);
    }
}

void ScanRomDirectory(std::vector<RomEntry>& rom_list) {
    const char* dir_path = "sd:/wiiu/apps/mupen64/roms/";
    DIR* dir = opendir(dir_path);
    if (!dir) {
        WHBLogWrite("Error: Could not open ROM directory!");
        return;
    }
    struct dirent* entry;
    uint32_t dummy_p = {0xFF0000FF, 0xFF0000FF, 0xFF0000FF, 0xFF0000FF};
    while ((entry = readdir(dir)) != nullptr) {
        std::string fname = entry->d_name;
        if (fname.find(".z64") != std::string::npos || fname.find(".n64") != std::string::npos) {
            RomEntry new_rom;
            new_rom.filename = fname;
            new_rom.display_name = fname.substr(0, fname.find_last_of("."));
            Texture_LoadRGBA(&new_rom.cover, dummy_p, 2, 2);
            rom_list.push_back(new_rom);
        }
    }
    closedir(dir);
}

int main(int argc, char **argv) {
    WHBProcInit();
    WHBLogUdpInit();
    OSScreenInit();
    
    size_t tv_size = OSScreenGetBufferSizeTV();
    void* tv_buffer = std::malloc(tv_size);
    OSScreenSetBufferTV(tv_buffer);
    OSScreenEnableTV(true);

    mupen_init();

    std::vector<RomEntry> menu_roms;
    ScanRomDirectory(menu_roms);

    if (menu_roms.empty()) {
        RomEntry no_game = {"", "No games found in sd:/wiiu/apps/mupen64/roms/", {}};
        menu_roms.push_back(no_game);
    }

    int32_t selected_index = 0;
    int32_t scroll_offset = 0;
    const int32_t MAX_VISIBLE_ITEMS = 8;
    
    bool in_menu = true;
    std::string active_rom_name = "";
    AspectRatio current_ratio = ASPECT_4_3;

    VPADStatus vpad;
    VPADReadError err;
    N64Controller n64_input;

    while (WHBProcIsRunning()) {
        VPADRead(VPAD_CHAN_0, &vpad, 1, &err);
        if (err != VPAD_READ_SUCCESS) std::memset(&vpad, 0, sizeof(VPADStatus));
        if (vpad.trigger & VPAD_BUTTON_HOME) break;

        OSScreenClearBufferTV(0x0A0F1D00);

        if (in_menu) {
            if (vpad.trigger & VPAD_BUTTON_DOWN) {
                selected_index++;
                if (selected_index >= (int32_t)menu_roms.size()) {
                    selected_index = 0;
                    scroll_offset = 0;
                }
                if (selected_index >= scroll_offset + MAX_VISIBLE_ITEMS) scroll_offset++;
            }
            if (vpad.trigger & VPAD_BUTTON_UP) {
                selected_index--;
                if (selected_index < 0) {
                    selected_index = (int32_t)menu_roms.size() - 1;
                    scroll_offset = selected_index - MAX_VISIBLE_ITEMS + 1;
                    if (scroll_offset < 0) scroll_offset = 0;
                }
                if (selected_index < scroll_offset) scroll_offset--;
            }
            
            if ((vpad.trigger & VPAD_BUTTON_A) && !menu_roms[selected_index].filename.empty()) {
                active_rom_name = menu_roms[selected_index].filename;
                std::string full_path = "sd:/wiiu/apps/mupen64/roms/" + active_rom_name;
                mupen_load_rom(full_path.c_str());
                in_menu = false;
            }

            OSScreenPutFontEx(SCREEN_TV, 2, 1, "=== MUPEN64PLUS WII U SELECTION MENU ===");
            int32_t render_count = 0;
            for (int32_t i = scroll_offset; i < (int32_t)menu_roms.size() && render_count < MAX_VISIBLE_ITEMS; ++i) {
                if (i == selected_index) {
                    char buf[256];
                    std::snprintf(buf, sizeof(buf), " > [ %s ]", menu_roms[i].display_name.c_str());
                    OSScreenPutFontEx(SCREEN_TV, 4, 4 + (render_count * 2), buf);
                    Texture_Bind(&menu_roms[i].cover, 0);
                } else {
                    OSScreenPutFontEx(SCREEN_TV, 6, 4 + (render_count * 2), menu_roms[i].display_name.c_str());
                }
                render_count++;
            }

            if (scroll_offset > 0) OSScreenPutFontEx(SCREEN_TV, 20, 3, "^^^ MORE ABOVE ^^^");
            if (scroll_offset + MAX_VISIBLE_ITEMS < (int32_t)menu_roms.size()) {
                OSScreenPutFontEx(SCREEN_TV, 20, 4 + (MAX_VISIBLE_ITEMS * 2), "vvv MORE BELOW vvv");
            }

        } else {
            // Safe aspect ratio trigger via Right Stick Click (R3)
            if (vpad.trigger & VPAD_BUTTON_STICK_R) {
                if (current_ratio == ASPECT_4_3) {
                    current_ratio = ASPECT_16_9;
                    WHBLogWrite("Aspect Ratio changed to 16:9");
                } else {
                    current_ratio = ASPECT_4_3;
                    WHBLogWrite("Aspect Ratio changed to 4:3");
                }
            }

            ApplyAspectRatio(current_ratio);

            if ((vpad.hold & VPAD_BUTTON_L) && (vpad.trigger & VPAD_BUTTON_ZR)) SaveState_Create(active_rom_name.c_str(), 1);
            if ((vpad.hold & VPAD_BUTTON_L) && (vpad.trigger & VPAD_BUTTON_ZL)) SaveState_Load(active_rom_name.c_str(), 1);

            // X button is now fully available for gameplay mapping
            std::memset(&n64_input, 0, sizeof(N64Controller));
            if (vpad.hold & VPAD_BUTTON_A) n64_input.buttons |= 0x8000; // N64 A
            if (vpad.hold & VPAD_BUTTON_B) n64_input.buttons |= 0x4000; // N64 B
            if (vpad.hold & VPAD_BUTTON_X) n64_input.buttons |= 0x0002; // N64 C-Left (Example mapping)
            if (vpad.hold & VPAD_BUTTON_Y) n64_input.buttons |= 0x0004; // N64 C-Down (Example mapping)
            
            n64_input.stick_x = vpad.leftStick.x * 127.0f;
            n64_input.stick_y = vpad.leftStick.y * 127.0f;

            mupen_run_frame(&n64_input);
            
            OSScreenPutFontEx(SCREEN_TV, 1, 1, "Game running... Press HOME to exit.");
            OSScreenPutFontEx(SCREEN_TV, 1, 2, "Press RIGHT STICK (R3) to toggle Aspect Ratio");
            
            char ratio_str[64];
            std::snprintf(ratio_str, sizeof(ratio_str), "Current Mode: %s", (current_ratio == ASPECT_4_3) ? "4:3 (Original)" : "16:9 (Widescreen)");
            OSScreenPutFontEx(SCREEN_TV, 1, 3, ratio_str);
        }
        OSScreenFlipBuffersTV();
    }

    for (auto& rom : menu_roms) Texture_Free(&rom.cover);
    mupen_shutdown();
    std::free(tv_buffer);
    WHBProcShutdown();
    return 0;
}
