#include <cstdio>
#include <cstdlib>
#include <whb/log.h>

extern uint8_t* g_n64_ram; 
extern uint32_t g_n64_ram_size;

extern "C" {
    bool SaveState_Create(const char* rom_name, int slot) {
        if (!g_n64_ram || g_n64_ram_size == 0) return false;

        char path[256];
        std::snprintf(path, sizeof(path), "sd:/wiiu/apps/mupen64/saves/%s.st%d", rom_name, slot);

        std::FILE* file = std::fopen(path, "wb");
        if (!file) {
            WHBLogWrite("Save error");
            return false;
        }

        std::fwrite(g_n64_ram, 1, g_n64_ram_size, file);
        std::fclose(file);
        WHBLogWrite("Saved");
        return true;
    }

    bool SaveState_Load(const char* rom_name, int slot) {
        if (!g_n64_ram || g_n64_ram_size == 0) return false;

        char path[256];
        std::snprintf(path, sizeof(path), "sd:/wiiu/apps/mupen64/saves/%s.st%d", rom_name, slot);

        std::FILE* file = std::fopen(path, "rb");
        if (!file) {
            WHBLogWrite("No file found");
            return false;
        }

        std::fread(g_n64_ram, 1, g_n64_ram_size, file);
        std::fclose(file);
        WHBLogWrite("Charged!");
        return true;
    }
}
