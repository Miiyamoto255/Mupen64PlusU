#include <coreinit/cache.h>
#include <gx2/texture.h>
#include <gx2/surface.h>
#include <gx2/mem.h>
#include <gx2/state.h>
#include <cstdlib>
#include <cstring>

struct WiiUTexture {
    GX2Texture gx2_tex;
    void* buffer;
    uint32_t width;
    uint32_t height;
    bool is_loaded;
};

extern "C" {
    bool Texture_LoadRGBA(WiiUTexture* tex, const void* rgba_data, uint32_t w, uint32_t h) {
        if (!tex || !rgba_data) return false;

        tex->width = w;
        tex->height = h;

        std::memset(&tex->gx2_tex, 0, sizeof(GX2Texture));
        tex->gx2_tex.surface.dim = GX2_SURFACE_DIM_TEXTURE_2D;
        tex->gx2_tex.surface.width = w;
        tex->gx2_tex.surface.height = h;
        tex->gx2_tex.surface.depth = 1;
        tex->gx2_tex.surface.mipLevels = 1;
        tex->gx2_tex.surface.format = GX2_SURFACE_FORMAT_UNORM_R8_G8_B8_A8;
        tex->gx2_tex.surface.use = GX2_SURFACE_USE_TEXTURE;
        tex->gx2_tex.surface.tileMode = GX2_TILE_MODE_LINEAR_ALIGNED;

        GX2CalcSurfaceSizeByFormat(&tex->gx2_tex.surface);
        
        uint32_t alignment = tex->gx2_tex.surface.alignment;
        tex->buffer = std::aligned_alloc(alignment, tex->gx2_tex.surface.imageSize);
        
        if (!tex->buffer) return false;

        std::memcpy(tex->buffer, rgba_data, w * h * 4);
        DCFlushRange(tex->buffer, tex->gx2_tex.surface.imageSize);

        tex->gx2_tex.viewNumMips = 1;
        tex->gx2_tex.viewNumSlices = 1;
        tex->gx2_tex.compMap = 0x00010203;
        GX2InitTextureRegs(&tex->gx2_tex);

        tex->is_loaded = true;
        return true;
    }

    void Texture_Bind(WiiUTexture* tex, uint32_t sampler_unit) {
        if (tex && tex->is_loaded) {
            GX2SetPixelTexture(&tex->gx2_tex, sampler_unit);
        }
    }

    void Texture_Free(WiiUTexture* tex) {
        if (tex && tex->buffer) {
            std::free(tex->buffer);
            tex->buffer = nullptr;
            tex->is_loaded = false;
        }
    }
}
